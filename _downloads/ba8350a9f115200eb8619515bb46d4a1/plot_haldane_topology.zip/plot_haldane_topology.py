r"""
The Haldane Model: Berry Curvature and a Topological Phase Transition
===========================================================================

The Haldane model is honeycomb graphene with a complex next-nearest-neighbor
hopping :math:`t_2 e^{i\phi}` (breaking time-reversal symmetry, e.g. via a
staggered flux pattern with zero net flux) and a staggered sublattice
onsite energy :math:`\pm M` (breaking inversion symmetry). It is the first
model shown to realize a Chern insulator -- a gapped phase with quantized
Hall conductance and no net magnetic field.

At the Dirac points :math:`K` and :math:`K'` the complex hopping opens
gaps of :math:`2|M \pm 3\sqrt{3}\,t_2\sin\phi|`, so the topological/trivial
phase boundary sits at Haldane's :math:`|M| = 3\sqrt{3}\,t_2\,|\sin\phi|`:
the lower band's Chern number, computed via
:meth:`~tbkit.kspace.KSpace.chern_number`, is :math:`\pm 1` for :math:`|M|`
below that (:math:`+1` here, with :math:`\phi=\pi/2`), 0 above it.
"""
import numpy as np
import matplotlib.pyplot as plt

from tbkit.lattice import Lattice
from tbkit.kspace import reciprocal_vectors, high_symmetry_path
from tbkit.system import System
from tbkit.plot import Plot
from tbkit import models


DX, DY = 0.5 * 3 ** 0.5, 0.5
unit_cell = [{'tag': 'a', 'r0': (0., 0.)}, {'tag': 'b', 'r0': (DX, DY)}]
prim_vec = [(2*DX, 0.), (DX, 1.5)]
t1, t2, phi = 1., 0.2, np.pi / 2
M_c = 3 * np.sqrt(3) * t2 * abs(np.sin(phi))  # critical mass (see module docstring)


# %%
# The lattice
# --------------
# The Haldane model lives on the plain honeycomb lattice -- two orbitals
# per unit cell, drawn in two colours below, with the nearest-neighbor
# bonds shown. What the model adds is invisible in this picture: a
# *second*-neighbor hopping within each sublattice, complex and of
# opposite chirality on the two, which is why it breaks time-reversal
# symmetry without any net flux through the cell.

patch = Lattice(unit_cell=unit_cell, prim_vec=prim_vec)
patch.get_lattice(n1=5, n2=4)
vis = System(patch)
vis.set_hopping([{'n': 1, 't': t1}])
fig_lat = Plot(vis).lattice(plt_hop=True, ms=12, figsize=(5.5, 4.5))

# %%
# Chern number across the topological phase transition
# ------------------------------------------------------------

masses = np.linspace(0., 2*M_c, 21)
chern = [models.haldane(t1, t2, phi, M=M).chern_number(bands=[0], nk=40) for M in masses]

# The gaps at K and K' are 2|M + M_c| and 2|M - M_c|: Haldane's formula,
# checked directly. The one at K' closes at M = M_c.
b1, b2 = (np.array(v) for v in reciprocal_vectors(prim_vec))
K_pt = (b1 - b2) / 3
for M in [0., 0.5*M_c, 1.5*M_c]:
    en_K = np.linalg.eigvalsh(models.haldane(t1, t2, phi, M=M).get_ham(K_pt))
    en_Kp = np.linalg.eigvalsh(models.haldane(t1, t2, phi, M=M).get_ham(-K_pt))
    assert np.isclose(en_K[1] - en_K[0], 2*abs(M + M_c), atol=1e-10)
    assert np.isclose(en_Kp[1] - en_Kp[0], 2*abs(M - M_c), atol=1e-10)

print('Critical mass M_c = 3*sqrt(3)*t2*sin(phi) = {:.4f}'.format(M_c))
print('Chern number at M=0            (topological): {:.4f}'.format(chern[0]))
print('Chern number at M=2*M_c        (trivial):      {:.4f}'.format(chern[-1]))
assert np.isclose(chern[0], 1., atol=1e-2)
assert np.isclose(chern[-1], 0., atol=1e-2)
print('Phase transition reproduced: C = 1 (topological) -> C = 0 (trivial). OK')

fig, ax = plt.subplots()
ax.plot(masses/M_c, chern, 'o-b')
ax.axvline(1., color='k', ls='--', lw=1)
ax.set_xlabel('$M/M_c$')
ax.set_ylabel('Chern number (lower band)')
ax.set_title('Haldane model: topological phase transition')

# %%
# Berry curvature in the topological phase
# ------------------------------------------------
# The total flux of :meth:`~tbkit.kspace.KSpace.berry_curvature` through
# the zone is :math:`2\pi`: the Chern number. With a gap this large
# (:math:`2M_c \approx 2t`) the curvature is spread over the whole zone
# rather than concentrated at the Dirac points.
# :meth:`~tbkit.kspace.KSpace.plot_berry_curvature` draws it as a density
# over the first Brillouin zone, the hexagon whose corners are K and K'.

hal_topological = models.haldane(t1, t2, phi, M=0.)
curv = hal_topological.berry_curvature(bands=[0], nk=60)
assert np.isclose(curv.sum(), 2 * np.pi, atol=1e-6)
fig2 = hal_topological.plot_berry_curvature(0, nk=60, fs=14)

# %%
# Band structure in the topological phase
# ------------------------------------------------
# :func:`~tbkit.kspace.high_symmetry_path` recognizes the hexagonal
# lattice and returns the path :math:`\Gamma` - M - K - :math:`\Gamma`.

points, labels = high_symmetry_path(hal_topological.lat)
hal_topological.k_path(points, nk=60)
fig3 = hal_topological.plot_bands(node_labels=labels)
